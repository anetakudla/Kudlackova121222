﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Kudlackova121222
{
    public partial class Form1 : Form
    {
        List<Zamestnanec> zamestnanci;
        SqlRepository sqlRepository = new SqlRepository();
        public Form1()
        {
            InitializeComponent();
            zamestnanci = sqlRepository.NactiZamestnance();
            RefreshTabulky();
        }
        public void RefreshTabulky()
        {
            listView1.Items.Clear();
            foreach (Zamestnanec zamestnanec in zamestnanci)
            {
                ListViewItem listViewItem = new ListViewItem(new string[] {
                    zamestnanec.Id.ToString(),
                    zamestnanec.Krestnijmeno.ToString(),
                    zamestnanec.Prijmeni.ToString(),
                    zamestnanec.Email.ToString(),
                    zamestnanec.Cislo.ToString(),
                    zamestnanec.Datum.ToString("dd.MM.yyyy")
                });
                listView1.Items.Add(listViewItem);
                listView1.Refresh();
            }
        }
        private void buttonPridat_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form2 form2 = new Form2();
            form2.Show();
        }

        private void buttonOdebrat_Click(object sender, EventArgs e)
        {
            if (listView1.SelectedItems.Count == 0)
            {
                MessageBox.Show("Vyber řádek!");
            }
            else
            {
                var vybranyRadek = listView1.SelectedItems[0];
                var idZamestnanec = vybranyRadek.SubItems[0].Text;
                sqlRepository.VymazZamestnance(idZamestnanec);
                listView1.SelectedItems[0].Remove();
            }
        }

        private void buttonEditovat_Click(object sender, EventArgs e)
        {
            if (listView1.SelectedItems.Count == 0)
            {
                MessageBox.Show("Row isn't selected");
            }
            else
            {
                this.Hide();
                Form3 form3 = new Form3();
                form3.Show();
                var selectedRow = listView1.SelectedItems[0];
                var id = selectedRow.SubItems[0].Text;
                var firstname = selectedRow.SubItems[1].Text;
                var lastname = selectedRow.SubItems[2].Text;
                var phone = selectedRow.SubItems[4].Text;
                var email = selectedRow.SubItems[3].Text;
                var birthday = selectedRow.SubItems[5].Text;

                form3.NacistZamestnance(id, firstname, lastname, phone, email, Convert.ToDateTime(birthday));
            }
        }
    }
}
