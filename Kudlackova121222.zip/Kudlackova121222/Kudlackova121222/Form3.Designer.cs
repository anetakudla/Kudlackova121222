﻿namespace Kudlackova121222
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonZavrit = new System.Windows.Forms.Button();
            this.buttonEditovani = new System.Windows.Forms.Button();
            this.textBoxCislo = new System.Windows.Forms.TextBox();
            this.textBoxEmail = new System.Windows.Forms.TextBox();
            this.textBoxPrijmeni = new System.Windows.Forms.TextBox();
            this.textBoxKrestniJmeno = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.dateTimePickerDatum = new System.Windows.Forms.DateTimePicker();
            this.labelIdZamestnance = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // buttonZavrit
            // 
            this.buttonZavrit.Location = new System.Drawing.Point(62, 215);
            this.buttonZavrit.Name = "buttonZavrit";
            this.buttonZavrit.Size = new System.Drawing.Size(50, 23);
            this.buttonZavrit.TabIndex = 25;
            this.buttonZavrit.Text = "Zavřít";
            this.buttonZavrit.UseVisualStyleBackColor = true;
            this.buttonZavrit.Click += new System.EventHandler(this.buttonZavrit_Click);
            // 
            // buttonEditovani
            // 
            this.buttonEditovani.Location = new System.Drawing.Point(118, 215);
            this.buttonEditovani.Name = "buttonEditovani";
            this.buttonEditovani.Size = new System.Drawing.Size(100, 23);
            this.buttonEditovani.TabIndex = 24;
            this.buttonEditovani.Text = "Editovat";
            this.buttonEditovani.UseVisualStyleBackColor = true;
            this.buttonEditovani.Click += new System.EventHandler(this.buttonEditovani_Click);
            // 
            // textBoxCislo
            // 
            this.textBoxCislo.Location = new System.Drawing.Point(118, 146);
            this.textBoxCislo.Name = "textBoxCislo";
            this.textBoxCislo.Size = new System.Drawing.Size(100, 20);
            this.textBoxCislo.TabIndex = 22;
            // 
            // textBoxEmail
            // 
            this.textBoxEmail.Location = new System.Drawing.Point(118, 120);
            this.textBoxEmail.Name = "textBoxEmail";
            this.textBoxEmail.Size = new System.Drawing.Size(100, 20);
            this.textBoxEmail.TabIndex = 21;
            // 
            // textBoxPrijmeni
            // 
            this.textBoxPrijmeni.Location = new System.Drawing.Point(118, 94);
            this.textBoxPrijmeni.Name = "textBoxPrijmeni";
            this.textBoxPrijmeni.Size = new System.Drawing.Size(100, 20);
            this.textBoxPrijmeni.TabIndex = 20;
            // 
            // textBoxKrestniJmeno
            // 
            this.textBoxKrestniJmeno.Location = new System.Drawing.Point(118, 68);
            this.textBoxKrestniJmeno.Name = "textBoxKrestniJmeno";
            this.textBoxKrestniJmeno.Size = new System.Drawing.Size(100, 20);
            this.textBoxKrestniJmeno.TabIndex = 19;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(21, 179);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(70, 13);
            this.label6.TabIndex = 18;
            this.label6.Text = "Datum naroz.";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(21, 153);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(31, 13);
            this.label5.TabIndex = 17;
            this.label5.Text = "Číslo";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(21, 127);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(32, 13);
            this.label4.TabIndex = 16;
            this.label4.Text = "Email";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(21, 101);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(48, 13);
            this.label3.TabIndex = 15;
            this.label3.Text = "Příjmení";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(21, 75);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(73, 13);
            this.label2.TabIndex = 14;
            this.label2.Text = "Křestní jméno";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label1.Location = new System.Drawing.Point(21, 29);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(195, 20);
            this.label1.TabIndex = 13;
            this.label1.Text = "Editování zaměstnance";
            // 
            // dateTimePickerDatum
            // 
            this.dateTimePickerDatum.Location = new System.Drawing.Point(118, 172);
            this.dateTimePickerDatum.Name = "dateTimePickerDatum";
            this.dateTimePickerDatum.Size = new System.Drawing.Size(100, 20);
            this.dateTimePickerDatum.TabIndex = 26;
            // 
            // labelIdZamestnance
            // 
            this.labelIdZamestnance.AutoSize = true;
            this.labelIdZamestnance.Location = new System.Drawing.Point(25, 53);
            this.labelIdZamestnance.Name = "labelIdZamestnance";
            this.labelIdZamestnance.Size = new System.Drawing.Size(35, 13);
            this.labelIdZamestnance.TabIndex = 27;
            this.labelIdZamestnance.Text = "label7";
            // 
            // Form3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(238, 266);
            this.Controls.Add(this.labelIdZamestnance);
            this.Controls.Add(this.dateTimePickerDatum);
            this.Controls.Add(this.buttonZavrit);
            this.Controls.Add(this.buttonEditovani);
            this.Controls.Add(this.textBoxCislo);
            this.Controls.Add(this.textBoxEmail);
            this.Controls.Add(this.textBoxPrijmeni);
            this.Controls.Add(this.textBoxKrestniJmeno);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "Form3";
            this.Text = "Form3";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button buttonZavrit;
        private System.Windows.Forms.Button buttonEditovani;
        private System.Windows.Forms.TextBox textBoxCislo;
        private System.Windows.Forms.TextBox textBoxEmail;
        private System.Windows.Forms.TextBox textBoxPrijmeni;
        private System.Windows.Forms.TextBox textBoxKrestniJmeno;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DateTimePicker dateTimePickerDatum;
        private System.Windows.Forms.Label labelIdZamestnance;
    }
}