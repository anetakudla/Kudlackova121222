﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Kudlackova121222
{
    public partial class Form3 : Form
    {
        SqlRepository sqlRepository = new SqlRepository();
        Form1 form1 = new Form1();
        public Form3()
        {
            InitializeComponent();
        }
        public void NacistZamestnance(string id, string krestnijmeno, string prijmeni, string email, string cislo, DateTime datum)
        {
            labelIdZamestnance.Text = id;
            textBoxKrestniJmeno.Text = krestnijmeno;
            textBoxPrijmeni.Text = prijmeni;
            textBoxEmail.Text = email;
            textBoxCislo.Text = cislo;
            dateTimePickerDatum.Value = datum;
        }
        private void buttonZavrit_Click(object sender, EventArgs e)
        {
            this.Close();
            Form1 form1 = new Form1();
            form1.Show();
        }

        private void buttonEditovani_Click(object sender, EventArgs e)
        {
            sqlRepository.UpravaZamestnance(labelIdZamestnance.Text, textBoxKrestniJmeno.Text, textBoxPrijmeni.Text, textBoxEmail.Text, textBoxCislo.Text, Convert.ToDateTime(dateTimePickerDatum.Value));
            this.Close();
            Form1 form1 = new Form1();
            form1.Show();
        }
    }
}
