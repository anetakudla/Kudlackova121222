﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kudlackova121222
{
    internal class SqlRepository
    {
        private string connectionString = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=KudlackovaDB;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False";

        public List<Zamestnanec> NactiZamestnance()
        {
            List<Zamestnanec> zamestnanci = new List<Zamestnanec>();
            try
            {
                using (SqlConnection sqlConnection = new SqlConnection(connectionString))
                {
                    sqlConnection.Open();
                    using (SqlCommand sqlCommand = new SqlCommand())
                    {
                        sqlCommand.Connection = sqlConnection;
                        sqlCommand.CommandText = "SELECT * FROM Zamestnanci";
                        using (SqlDataReader sqlDataReader = sqlCommand.ExecuteReader())
                        {
                            while (sqlDataReader.Read())
                            {
                                var zamestnanec = new Zamestnanec()
                                {
                                    Id = Convert.ToInt32(sqlDataReader["Id"]),
                                    Krestnijmeno = sqlDataReader["Krestnijmeno"].ToString(),
                                    Prijmeni = sqlDataReader["Prijmeni"].ToString(),
                                    Email = sqlDataReader["Email"].ToString(),
                                    Cislo = sqlDataReader["Cislo"].ToString(),
                                    Datum = Convert.ToDateTime(sqlDataReader["Datum"])
                                };
                                zamestnanci.Add(zamestnanec);
                            }
                        }
                    }
                    sqlConnection.Close();
                }
            }
            catch (Exception ex)
            {
                throw new Exception($"Chyba: (Exception: {ex.Message})");
            }
            return zamestnanci;
        }
        public void VymazZamestnance(string idZamestnanec)
        {
            try
            {
                using (SqlConnection sqlConnection = new SqlConnection(connectionString))
                {
                    sqlConnection.Open();
                    using (SqlCommand sqlCommand = new SqlCommand())
                    {
                        sqlCommand.Connection = sqlConnection;
                        sqlCommand.CommandText = $"DELETE FROM Zamestnanci WHERE Id={idZamestnanec}";
                        sqlCommand.ExecuteNonQuery();
                    }
                    sqlConnection.Close();
                }
            }
            catch (Exception ex)
            {
                throw new Exception($"Chyba: (Exception: {ex.Message})");
            }
        }
        public void PridejZamestnance(string krestnijmeno, string prijmeni, string email, string cislo, DateTime datum)
        {
            try
            {
                using (SqlConnection sqlConnection = new SqlConnection(connectionString))
                {
                    sqlConnection.Open();
                    using (SqlCommand sqlCommand = new SqlCommand())
                    {
                        sqlCommand.Connection = sqlConnection;
                        sqlCommand.CommandText = $"INSERT INTO Zamestnanci (Krestnijmeno, Prijmeni, Email, Cislo, Datum) VALUES (@krestnijmeno,@prijmeni,@email,@cislo, @datum)";
                        sqlCommand.Parameters.AddWithValue("@krestnijmeno", krestnijmeno);
                        sqlCommand.Parameters.AddWithValue("@prijmeni", prijmeni);
                        sqlCommand.Parameters.AddWithValue("@email", email);
                        sqlCommand.Parameters.AddWithValue("@cislo", cislo);
                        sqlCommand.Parameters.AddWithValue("@datum", datum);
                        sqlCommand.ExecuteNonQuery();
                    }
                    sqlConnection.Close();
                }
            }
            catch (Exception ex)
            {
                throw new Exception($"Chyba: {ex.Message})");
            }
        }
        public void UpravaZamestnance(string id,string krestnijmeno, string prijmeni, string email, string cislo, DateTime datum)
        {
            try
            {
                using (SqlConnection sqlConnection = new SqlConnection(connectionString))
                {
                    sqlConnection.Open();
                    using (SqlCommand sqlCommand = new SqlCommand())
                    {
                        sqlCommand.Connection = sqlConnection;
                        sqlCommand.CommandText = "UPDATE Zamestnanci SET Krestnijmeno=@krestnijmeno, Prijmeni=@prijmeni, Email=@email, Cislo=@cislo, Datum=@datum WHERE  Id=@id ";
                        sqlCommand.Parameters.AddWithValue("@id", id);
                        sqlCommand.Parameters.AddWithValue("@krestnijmeno", krestnijmeno);
                        sqlCommand.Parameters.AddWithValue("@prijmeni", prijmeni);
                        sqlCommand.Parameters.AddWithValue("@email", email);
                        sqlCommand.Parameters.AddWithValue("@cislo", cislo);
                        sqlCommand.Parameters.AddWithValue("@datum", datum);
                        sqlCommand.ExecuteNonQuery();
                    }
                    sqlConnection.Close();
                }
            }
            catch (Exception ex)
            {
                throw new Exception($"Chyba: (Exception: {ex.Message})");
            }
        }
    }
}
