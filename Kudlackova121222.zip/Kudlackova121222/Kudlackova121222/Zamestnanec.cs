﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kudlackova121222
{
    public class Zamestnanec
    {
        public int Id { get; set; }
        public string Krestnijmeno { get; set; }
        public string Prijmeni { get; set; }
        public string Email { get; set; }
        public string Cislo { get; set; }
        public DateTime Datum { get; set; }
    }
}
